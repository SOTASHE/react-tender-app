// Snaye Sotashe

//Task
// Create a loop that iterates up to 100 while outputting “Anna” at multiples of 3, “belle” at multiples of 5, and “Annabelle” at multiples of 3 and 5


const annabelle = "Annabelle";  // this is the string that will be outputted at multiples of 3 and 5 (3 and 5 because 3 and 5 are the multiples of 3 and 5)

for (let i = 1; i <= 100; i++) {   // this loop will iterate up to 100 (the number of times the string will be outputted) 
    if (i % 3 === 0 && i % 5 === 0) {  // if the number is divisible by 3 and 5, the string will be outputted at that number (3 and 5 because 3 and 5 are the multiples of 3 and 5)
        console.log(annabelle);
    } else if (i % 3 === 0) {  // if the number is divisible by 3, the string will be outputted at that number (3 because 3 is the multiple of 3)
        console.log("Anna");
    } else if (i % 5 === 0) {  // if the number is divisible by 5, the string will be outputted at that number (5 because 5 is the multiple of 5)
        console.log("belle");
    }
}

    



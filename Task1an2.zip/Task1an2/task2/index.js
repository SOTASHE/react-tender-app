//Snaye Sotashe

//Task2
// Create a JavaScript function that returns true if two words are anagrams
//e.g. “Elbow” and “Below” are anagrams

const isAnagram = (str1, str2) => { // str1 and str2 are two strings
    
    const sorted1 = str1.toLowerCase().split("").sort().join("");  //sort() sorts the array alphabetically and join() joins the array into a string

    const sorted2 = str2.toLowerCase().split("").sort().join(""); 

  return str1 !== str2 && sorted1 === sorted2; // return true if the two strings are not the same and if the two strings are anagrams (if they are sorted)
};

//test for true
console.log(isAnagram("Elbow", "Below")); // true

//test for false
console.log(isAnagram("Elbow", "Below2")); // false





